spark-submit --class als.MatrixStatistics --master spark://soit-hdp-pro-1.ucc.usyd.edu.au:7077  --total-executor-cores 10 SparkAdv.jar hdfs://soit-hdp-pro-1.ucc.usyd.edu.au:8020/share/movie/small/  
